import pandas as pd

df = pd.read_csv("employees_to_leave_sorted.csv")
print(df.columns.tolist())
